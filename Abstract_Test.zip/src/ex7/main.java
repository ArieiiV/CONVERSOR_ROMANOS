package ex7;

import javax.swing.JOptionPane;

public class main {

	public static void main(String [] args) {
		
		String str = JOptionPane.showInputDialog("Digite um numero");
		
		Integer primo = Integer.parseInt(str);
				
		if(verifica(primo)) {
			JOptionPane.showMessageDialog(null, "Nao primo");
		}else {
			JOptionPane.showMessageDialog(null, "Primo");
		}
		
	}
	
	public static boolean verifica(Integer primo) {
		for(int i = 2; i < primo; i ++) {
			if(primo % i == 0) {
				return(true);
			}
		}
		return false;
	}
	
}
