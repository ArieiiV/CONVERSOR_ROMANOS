
public class Programador extends Funcionario {

	public void bonifica(double bonus) {
		System.out.print("Salario do programador: ");
		setSalario(6500 * (bonus + 1));
		System.out.print(getSalario());
	}

}
