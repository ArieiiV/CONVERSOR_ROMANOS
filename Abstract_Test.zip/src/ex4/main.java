package ex4;

import javax.swing.JOptionPane;

public class main {
	
	public static void main(String[]args) {
		
		String str = JOptionPane.showInputDialog("Digite sua idade");
		
		Integer idade = Integer.parseInt(str);
		
		if(idade < 16) {
			JOptionPane.showMessageDialog(null, "N�o votante");
		}else if(idade >=18 && idade <=70) {
			JOptionPane.showMessageDialog(null, "Votante obrigat�rio");
		}else if(idade < 18 || idade > 70) {
			JOptionPane.showMessageDialog(null, "Votante voluntario");
		}
		
		
	}

}
