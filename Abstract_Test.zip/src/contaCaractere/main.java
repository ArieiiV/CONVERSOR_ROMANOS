package contaCaractere;

import javax.swing.JOptionPane;

public class main {

	public static void main(String [] args) {
	
		String str = JOptionPane.showInputDialog("Digite a string ");
		JOptionPane.showMessageDialog(null, str.length());
		
	}
}
