
public class Bonifica {

	public static void main(String[] args) {
		Funcionario f = new Programador();
		
		f = func(f, true);		
		f.setBonus(1);
		f.bonifica(f.getBonus());
	}
	
	private static Funcionario func(Funcionario f, boolean t) {
		if(t == true) {
			f = new Programador();
		}else {
			f = new Analista();
		}
		return f;
	}
}
