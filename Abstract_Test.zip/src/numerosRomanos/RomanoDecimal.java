package numerosRomanos;

public class RomanoDecimal {

	private char[] libr = { 
			'M', // 1000
			'D', // 500
			'C', // 100
			'L', // 50
			'X', // 10
			'V', // 5
			'I' // 1
	};

	public RomanoDecimal(String romano) {
		boolean valida = true;
		
		romano = romano.toUpperCase();
		for (int i = 0; i < romano.length() - 1; i++) {
			if (romano.charAt(i) != 'M' && romano.charAt(i) != 'C' && romano.charAt(i) != 'X' && romano.charAt(i) != 'V'
					&& romano.charAt(i) != 'I' && romano.charAt(i) != 'L' && romano.charAt(i) != 'D') {
				valida = false;
				break;
			}
		}

		if (valida) {
			//romano += " "; //Corre��o alternativa.
			
			//Antes de apresentar o valor verificar se � um numero valido
						
			apresenta(romano);
			

		} else {

			System.out.print("Invalido.\n\n");

		}

	}

	public int converte(char r) {
		int x = 0;
		if (r == libr[0]) {
			x = 1000;
		} else if (r == libr[1]) {
			x = 500;
		} else if (r == libr[2]) {
			x = 100;
		} else if (r == libr[3]) {
			x = 50;
		} else if (r == libr[4]) {
			x = 10;
		} else if (r == libr[5]) {
			x = 5;
		} else if (r == libr[6]) {
			x = 1;
		}
		return x;
	}

	public String separa(String r, int index) {
		String str = "";
		if (r.length() > index) {
			if (converte(r.charAt(index)) < converte(r.charAt(index + 1))) {
				str += r.charAt(index);
				str += r.charAt(index + 1);
			} else {
				str += r.charAt(index);
			}

		}
		return str;
	}

	public int decimalRomano(String str) {

		int decimal = 0;

		if (str.length() == 2) {
			decimal = converte(str.charAt(1));
			decimal -= converte(str.charAt(0));
		} else {
			decimal = converte(str.charAt(0));
		}

		return decimal;
	}
	
	public void apresenta(String romano) {
		int decimal = 0;
		String x = "";

		for (int i = 0; i < romano.length() - 1; i++) {
			x = separa(romano, i);
			if(x.length() == 2) {
				i += 1;
				decimal += decimalRomano(x);
			}else if(x.length() == 1){
				decimal += decimalRomano(x);
			}
		}
		System.out.print("Numero decimal: " + decimal);
	}
}
