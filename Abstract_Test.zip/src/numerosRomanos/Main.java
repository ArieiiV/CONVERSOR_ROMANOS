package numerosRomanos;

import java.util.Scanner;

public class Main {

	private static int Decimal;
	private static String Romano;

	public static void main(String[] args) {

		while (true) {
			System.out.print("Digite:\n1 - Decimal para romano.\n2 - Romano para decimal.");
			Scanner entrada = new Scanner(System.in);

			String x = entrada.next();
			entrada.nextLine();

			switch (x) {
			case "1":

				System.out.print("Entre com um numero decimal.\n\n");
				setDecimal(entrada.nextInt());
				DecimalRomano dr = new DecimalRomano(getDecimal());

				break;

			case "2":

				System.out.print("\n\n\nEntre com um numero romano.\n\n");
				setRomano(entrada.next());
				RomanoDecimal rd = new RomanoDecimal(getRomano());

				break;

			default:
				break;
			}
		}

	}

	public static void setDecimal(int decimal) {
		Decimal = decimal;
	}

	public static int getDecimal() {
		return Decimal;
	}

	public static void setRomano(String romano) {
		Romano = romano;
	}

	public static String getRomano() {
		return Romano;
	}

}
