package numerosRomanos;

public class DecimalRomano {
	
	public DecimalRomano(int decimal) {
		
		String romano = "";
		
		if(decimal > 0 && decimal <= 3999) {
		
			System.out.println("\n\n\nNumero Decimal: " + decimal);
			while(decimal != 0) {
				if(decimal >= 1000) {
					decimal -= 1000;
					romano += "M";
				}else if(decimal >= 900) {
					decimal -= 900;
					romano += "CM";
				}else if(decimal >= 500){
					romano += "D";
					decimal-=500;
				}else if(decimal >= 400) {
					romano += "CD";
					decimal-= 400;
				}else if(decimal >= 100) {
					romano += "C";
					decimal-= 100;
				}else if(decimal >= 90) {
					romano += "CX";
					decimal-= 90;
				}else if(decimal >= 50) {
					romano += "L";
					decimal-= 50;
				}else if(decimal >= 40) {
					romano += "XL";
					decimal-= 40;
				}else if(decimal >= 10) {
					romano += "X";
					decimal-= 10;
				}else if(decimal >= 9){
					romano += "IX";
					decimal-=9;
				}else if(decimal >= 5) {
					romano += "V";
					decimal-= 5;
				}else if(decimal >= 4) {
					romano += "IV";
					decimal-= 4;
				}else if(decimal >= 1) {
					romano += "I";
					decimal-= 1;
				}
			}
			
			System.out.println("Numero Romano: " + romano);
		}else {
			System.out.print("Apenas entre 1 e 999.");
		}
		
		
	}
	
}
