package interface_teste;

public class Gerente extends Funcionario implements Colaborador {

	public double bonus = 0.03;
	public double salario = 1200;
	public String[] funcionarios = {
		"leonardo",
		"jose", 
		"anna",
		"alex",
		"jefferson",
	};

	@Override
	public void bonifica(double salario, double bonus) {
		this.salario = salario * (bonus + 1);
	}

	@Override
	public String[] desliga(String funcionario) {
		int index = 0;
		try {
			for (index = 0; index < 999; index++) {
				System.out.println("Funcionario teste " + this.funcionarios[index] + index);
			}
		} catch (Exception e) {
			System.out.println("Teste completo, tem " + index + " Vetores.");
		}

		try {
			String[] func = new String[index - 1];
			boolean t = false;

			for (int i = 0; i < index; i++) {
				if (this.funcionarios[i] == funcionario) {
					t = true;
					continue;
				} else if (!t) {
					func[i] = this.funcionarios[i];
				} else {
					func[i - 1] = this.funcionarios[i];
				}
			}
			return func;
		}catch(Exception e) {
			return null;
		}
	}

	@Override
	public String[] contrata(String funcionario) {
		int index = 0;
		try {
			for (index = 0; index < 999; index++) {
				System.out.println("Funcionario teste " + this.funcionarios[index] + index);
			}
		} catch (Exception e) {
			System.out.println("Teste completo, tem " + index + " Vetores.");
		}

		String[] func = new String[index + 1];

		for (int i = 0; i < index; i++) {
			func[i] = this.funcionarios[i];
		}
		func[index] = funcionario;

		return func;
	}
	
	@Override
	public void promove(String funcionarios) {
		// TODO Auto-generated method stub
		
	}

}
