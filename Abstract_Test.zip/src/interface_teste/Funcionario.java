package interface_teste;

public abstract class Funcionario {

}
