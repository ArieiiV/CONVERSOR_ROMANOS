package interface_teste;

public class Main {

	public static void main(String[] args) {
		Estagiario e = new Estagiario();

		System.out.printf("Salario antes da bonifica��o %f\n", e.salario);
		e.bonifica(e.salario, e.bonus);
		System.out.printf("Salario depois da bonifica��o %f\n", e.salario);

		e.promove("seila");
		
		Programador p = new Programador();
		
		int index = 0;
		try {
			for (index = 0; index < 999; index++) {
				System.out.println("2Funcionario teste " + p.funcionarios[index] + index);
			}
		} catch (Exception oe) {
			System.out.println("Teste completo, tem " + index + " Vetores.\n\n\n\n");
		}
		
	}
}
