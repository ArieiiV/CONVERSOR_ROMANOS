package interface_teste;

public interface Colaborador {

	public void bonifica(double salario, double bonus);
	
	public String[] desliga(String funcionarios);
	
	public String[] contrata(String funcionarios);
	
	public void promove(String funcionarios);
	
}
