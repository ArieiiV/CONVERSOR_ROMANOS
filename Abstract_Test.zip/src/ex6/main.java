package ex6;

import javax.swing.JOptionPane;

public class main {

	public static void main(String[] args) {
		Double n;
		double x = 0;
		do {
			String str = JOptionPane.showInputDialog("Digite um numero");

			n = Double.parseDouble(str);

			x += n;
			
			JOptionPane.showMessageDialog(null, x);

		} while (n <= 10000);
		
		JOptionPane.showMessageDialog(null, "Passou 10000. " + x);

	}

}
