package ex1;

import javax.swing.JOptionPane;

public class main {
	
	public static void main(String [] args) {
		String str =JOptionPane.showInputDialog("Digite sua idade ");
		
		Integer idade = Integer.parseInt(str);
			
		if(idade >= 18) {
			JOptionPane.showMessageDialog(null, "de maior");
		}else {
			JOptionPane.showMessageDialog(null, "de menor");
		}
		
	}
	
	
}
