
public class Analista extends Funcionario {

	public void bonifica(double bonus) {
		System.out.print("Salario do analista: ");
		setSalario(5000 * (bonus + 1));
		System.out.print(getSalario());
	}

}
