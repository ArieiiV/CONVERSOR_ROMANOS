package ex2;

import javax.swing.JOptionPane;

public class main {
	 
	public static void main(String [] args) {
		String str = JOptionPane.showInputDialog("Digite seu sexo (F/M)");
		
		if(str.equals("m") || str.equals("M")) {
			JOptionPane.showMessageDialog(null, "Masculino");
		}else if(str.equals("f") || str.equals("F")) {
			JOptionPane.showMessageDialog(null, "Feminino");
		}else {
			JOptionPane.showMessageDialog(null, "Sexo invalido");
		}
	}
	
}
