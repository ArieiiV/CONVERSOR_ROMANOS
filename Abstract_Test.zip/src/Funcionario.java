
abstract class Funcionario {

	private double bonus = 0;
	private double salario = 0;

	public double getBonus() {
		return this.bonus;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public double getSalario() {
		return this.salario;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus / 100;
	}

	abstract void bonifica(double salario);

}
