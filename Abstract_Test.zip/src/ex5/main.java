package ex5;

import javax.swing.JOptionPane;

public class main {

	public static void main(String [] args) {
		String str = JOptionPane.showInputDialog("Digite um numero");
		
		Integer n = Integer.parseInt(str);
		
		String texto = "";
		
		for(Integer index = 0; index <= 10; index ++) {
			
			texto += n.toString() + " x " + index.toString() + " = " + n*index + "\n";
			
		}
		
		JOptionPane.showMessageDialog(null, texto);
		
	}
	
}
