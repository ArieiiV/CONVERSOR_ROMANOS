package br.com.uninove;

public interface Numero {
	public <E>E converter();
}