    
package br.com.uninove;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;


public class NumeroRomano implements Numero{

	private Map<String, Integer> romanosParaInteiro;
	private String numero;
	
	public NumeroRomano(String numero) {
		this.numero = numero;

		romanosParaInteiro = new HashMap<String, Integer>();
		romanosParaInteiro.put("I", 1);
		romanosParaInteiro.put("II", 2);
		romanosParaInteiro.put("III", 3);
		romanosParaInteiro.put("IV", 4);
		romanosParaInteiro.put("V", 5);
		romanosParaInteiro.put("VI", 6);
		romanosParaInteiro.put("VII", 7);
		romanosParaInteiro.put("VIII", 8);
		romanosParaInteiro.put("IX", 9);
		romanosParaInteiro.put("X", 10);
		romanosParaInteiro.put("L", 50);
		romanosParaInteiro.put("C", 100);
		romanosParaInteiro.put("D", 500);
		romanosParaInteiro.put("M", 1000);
	}
	
	private Integer retornarNumero(String romano) {
		if(romano != null && !romano.isEmpty()){
			romano = romano.toUpperCase();
			Integer numeroInteiro = romanosParaInteiro.get(romano);
			
			if(numeroInteiro == null){
				numeroInteiro = 0;
				
				validacaoNumeroRomano(romano);
				int i = 0;
				
				while (i < romano.length()) {
			          
		             String letraRomana = new Character(romano.charAt(i)).toString(); 
		             
		             if(romanosParaInteiro.containsKey(letraRomana)){
			             int numeroAtual = romanosParaInteiro.get(letraRomana); 			             
			             i++; 	
			             
			             if (i == romano.length()) {			                 
			            	 numeroInteiro += numeroAtual;
			             }
			             else {			            	 
			            	 String romanoProximo = new Character(romano.charAt(i)).toString(); 
			            	 
			                int numeroProximo = romanosParaInteiro.get(romanoProximo);
			                if (numeroProximo > numeroAtual) {
			                	numeroInteiro += (numeroProximo - numeroAtual);
			                	i++; 
			                }
			                else {
			                	numeroInteiro += numeroAtual;
			                }
			             }
		             }else {
		            	 JOptionPane.showMessageDialog(null, "VALOR INV�LIDO, O PROGRAMA SER� FINALIZADO");
						throw new NumberFormatException("VALOR INV�LIDO !!!!");
		             }
		             
		          }   
			}
			
			return numeroInteiro;
		}
		return null;
	}
	
	
	private void validacaoNumeroRomano(String romano){
		Pattern pattern = Pattern.compile("^M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$");
		Matcher matcher = pattern.matcher(romano);
		boolean regexValido = matcher.matches();
		
		if(!regexValido){
			JOptionPane.showMessageDialog(null, "VALOR INV�LIDO, O PROGRAMA SER� FINALIZADO");
			throw new NumberFormatException("N�MEROS INV�LIDOS");
		}
	}
		
	@SuppressWarnings("unchecked")
	public <E>E converter() {
		return (E) this.retornarNumero(numero);
	}
	
}