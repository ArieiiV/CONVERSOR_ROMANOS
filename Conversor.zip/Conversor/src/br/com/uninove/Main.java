package br.com.uninove;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {

		while (true) {
			String numeroRomano = JOptionPane.showInputDialog("Digite o n�mero Romano a ser convertido ");
			if (numeroRomano.trim() != null && !numeroRomano.trim().isEmpty()) {

				Numero conversor = null;

				conversor = new NumeroRomano(numeroRomano);

				JOptionPane.showMessageDialog(null, "VALOR CONVERTIDO: "+ conversor.converter());

			} else {
				JOptionPane.showMessageDialog(null," DIGITE UM VALOR ");
			}
		}

	}

}
